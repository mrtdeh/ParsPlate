<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>

	<?php $__env->startSection("startHead"); ?>
	<?php echo $__env->yieldSection(); ?>

	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta charset="utf-8" >
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="icon" href="../../favicon.ico">
  

    <?php $__env->startSection("endHead"); ?>
	<?php echo $__env->yieldSection(); ?>

</head>

<body>





	<main>
	   
	    <?php $__env->startSection("main"); ?>
	    <?php echo $__env->yieldSection(); ?>

	</main>






	

	<?php $__env->startSection("endBody"); ?>
	<?php echo $__env->yieldSection(); ?>



</body>

</html>