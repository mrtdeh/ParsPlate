<?php $__env->startSection("jumbotron"); ?>

        
    <div class="jumbotron" >


        <div class="container">
            <div class="text-center">
                
                <div class="pt-5">
                    <h2>اعتبار ما اعتماد شماست</h2>
                </div>
                <div class="pt-2">
                    <p>شس یشسیس سیسشسشال شل شسایش س ششسلبی شسیشهعی شسزیس ایسصثف قلطز سی یسابسیاب</p>
                </div>
            </div>
        </div>



    </div>


<?php $__env->stopSection(); ?>




<?php $__env->startSection("main"); ?>

    <div class="container">
    
        <?php echo $__env->make("components/templatesList", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection("startHead"); ?>

    <link rel='stylesheet' href='<?php echo asset('/css/'.basename(mix('/css/app.css'))) ?>'/>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection("endBody"); ?>

    <?php echo $__env->make("jsVars", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src='<?php echo asset('/js/'.basename(mix('/js/manifest.js'))) ?>'></script><script src='<?php echo asset('/js/'.basename(mix('/js/vendor.js'))) ?>'></script><script src='<?php echo asset('/js/'.basename(mix('/js/app.js'))) ?>'></script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>