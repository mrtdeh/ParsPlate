<?php $__env->startSection("dashboard","active"); ?>


<?php $__env->startSection("main"); ?>

	
dfg

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>