<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Template;

class TemplatesController extends Controller
{
    

	public function index()
	
	{
		$templates = Template::take(8)->orderBy("id","desc")->get();
    	
    	$templateCount = Template::count();

    	// JavaScript::put([

    	//     'ControllerName' => 'home',

    	//     'Templates' => $templates,
    	// ]);

		return view("admin.templates", compact("templates"));
	
	}

}
