@extends("layouts.admin")

@section("templates","active")


@section("main")

	

	<form action="/template" method="post"  enctype="multipart/form-data">

		{{ csrf_field() }}


		<div class="form-group">
		
			
		
			<input type="text" placeholder="عنوان" class="form-control"  name="title">
		
		</div>
		

		<div class="form-group">
		
			
		
			<textarea placeholder="توضیحات" class="form-control" name="desc"></textarea>
		
		</div>
		

		<div class="form-group">
		
			<label for="aaa">تصویر قالب :</label>
		
			<input type="file" name="cover" id="aaa">
		
		</div>
		

		@include("errors")
			

	  	<button type="submit" class="btn btn-success">ثبت</button>
	  	
	</form>




	<div class="templates">
		<table class="table">
		  <thead>
		    <tr>
		      <th>#</th>
		      <th>عنوان قالب</th>
		      <th>تاریخ ایجاد</th>
		      <th>دسته بندی</th>
		      <th>عملیات</th>
		    </tr>
		  </thead>
		  <tbody>

		  	@forelse($templates as $i => $template)
			    <tr>
			      <th scope="row">{{ $i }}</th>
			      <td>{{ $template->title }}</td>
			      <td>{{ jDate::forge($template->created_at)->ago() }}</td>
			      <td>Otto</td>
			      <td>

			      		<div class="btn-group">
			      			<button class="btn btn-danger">Delete</button>
			      		</div>

			      </td>

			    </tr>
			@empty
				<tr>هیچ رکوردی یافت نشد</tr>
			@endforelse

		  </tbody>
		</table>
	</div>


@endsection
